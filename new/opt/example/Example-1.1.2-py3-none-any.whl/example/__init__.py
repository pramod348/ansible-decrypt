from flask import Flask, render_template
import os


def create_app():
    app = Flask(
        __name__,
        template_folder='routes/templates',
        instance_path=os.getenv('INSTANCE_PATH'),
        instance_relative_config=True
    )
    app.config.from_pyfile('config.py')

    from example.routes import content
    app.register_blueprint(content.bp)

    @app.route('/')
    def index():
        return render_template('index.html')
    
    return app